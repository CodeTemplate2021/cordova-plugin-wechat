package com.jxm.app.wxapi;
/**
* Chen Yu 2021/11/25
**/
public class WXEntryActivity extends EntryActivity {
}
