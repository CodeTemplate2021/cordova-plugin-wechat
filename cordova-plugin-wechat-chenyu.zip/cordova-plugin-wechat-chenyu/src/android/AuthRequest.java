package plugin.wechat.chenyu;
/**
* Chen Yu 2021/11/25
**/
public class AuthRequest {
}
